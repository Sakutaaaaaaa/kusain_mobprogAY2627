
import 'package:flutter/material.dart';
import '../widgets/newsfeed_card.dart';

class NewsFeedScreen extends StatelessWidget {
  const NewsFeedScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      children: const [
        NewsFeedCard(
          userName: 'Jerome Tugadi',
          postContent: 'angas',
          numOfLikes: 69,
          date: 'November 20',
          hasImage: true,
          profileImageUrl: 'https://i.pravatar.cc/150?img=11',
          postImageUrl: 'https://picsum.photos/seed/jerome/600/400',
        ),

        NewsFeedCard(
          userName: 'Matt Kusain',
          postContent: 'omggg',
          numOfLikes: 200,
          date: 'December 2',
          hasImage: true,
          profileImageUrl: 'https://i.pravatar.cc/150?img=12',
          postImageUrl: 'https://picsum.photos/seed/matt/600/400',
        ),

        NewsFeedCard(
          userName: 'Katelyn Urbano',
          postContent: 'Good morning everyone!',
          numOfLikes: 45,
          date: 'November 21',
          hasImage: false,
          profileImageUrl: 'https://i.pravatar.cc/150?img=5',
        ),

        NewsFeedCard(
          userName: 'John Mark',
          postContent: 'Enjoying my day!',
          numOfLikes: 87,
          date: 'November 21',
          hasImage: true,
          profileImageUrl: 'https://i.pravatar.cc/150?img=13',
          postImageUrl: 'https://picsum.photos/seed/john/600/400',
        ),

        NewsFeedCard(
          userName: 'Aira Jane',
          postContent: 'Keep going, you are doing great.',
          numOfLikes: 120,
          date: 'November 22',
          hasImage: false,
          profileImageUrl: 'https://i.pravatar.cc/150?img=9',
        ),

        NewsFeedCard(
          userName: 'Christian Reyes',
          postContent: 'Weekend vibes!',
          numOfLikes: 56,
          date: 'November 22',
          hasImage: true,
          profileImageUrl: 'https://i.pravatar.cc/150?img=14',
          postImageUrl: 'https://picsum.photos/seed/christian/600/400',
        ),

        NewsFeedCard(
          userName: 'Angela Cruz',
          postContent: 'Finally finished my project!',
          numOfLikes: 310,
          date: 'November 23',
          hasImage: false,
          profileImageUrl: 'https://i.pravatar.cc/150?img=20',
        ),

        NewsFeedCard(
          userName: 'Mark Santos',
          postContent: 'Nothing beats good food.',
          numOfLikes: 95,
          date: 'November 23',
          hasImage: true,
          profileImageUrl: 'https://i.pravatar.cc/150?img=15',
          postImageUrl: 'https://picsum.photos/seed/mark/600/400',
        ),

        NewsFeedCard(
          userName: 'Nicole Garcia',
          postContent: 'Stay positive!',
          numOfLikes: 150,
          date: 'November 24',
          hasImage: false,
          profileImageUrl: 'https://i.pravatar.cc/150?img=24',
        ),

        NewsFeedCard(
          userName: 'David Lim',
          postContent: 'Another day, another opportunity.',
          numOfLikes: 72,
          date: 'November 24',
          hasImage: true,
          profileImageUrl: 'https://i.pravatar.cc/150?img=16',
          postImageUrl: 'https://picsum.photos/seed/david/600/400',
        ),
      ],
    );
  }
}
